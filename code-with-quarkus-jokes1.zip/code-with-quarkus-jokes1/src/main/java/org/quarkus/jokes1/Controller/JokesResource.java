package org.quarkus.jokes1.Controller;

import io.smallrye.mutiny.Uni;
import jakarta.inject.Inject;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import org.quarkus.jokes1.Entity.Joke;
import org.quarkus.jokes1.Service.JokesService;

import java.util.List;

@Path("/jokes")
public class JokesResource {

    @Inject
    JokesService jokesService;

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Uni<List<Joke>> getJokes(@QueryParam("count") int count) {
        return jokesService.getJokes(count);
    }
}

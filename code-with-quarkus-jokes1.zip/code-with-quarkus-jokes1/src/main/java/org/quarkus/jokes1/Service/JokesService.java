package org.quarkus.jokes1.Service;

import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.mysqlclient.MySQLPool;
import io.vertx.mutiny.sqlclient.Row;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.quarkus.jokes1.Controller.JokeClient;
import org.quarkus.jokes1.Entity.Joke;
import java.util.List;

@ApplicationScoped
public class JokesService {

    @Inject
    public MySQLPool mysqlClient;

    @Inject
    @RestClient
    JokeClient jokeClient;

    public Uni<List<Joke>> getJokes(int count) {
        return fetchAndSaveJokes(count);
    }

    private Uni<List<Joke>> fetchAndSaveJokes(int count) {
        Uni<Void> jokeFetchingUni = Uni.createFrom().voidItem();
        for (int i = 0; i < count; i++) {
            jokeFetchingUni = jokeFetchingUni
                    .onItem().transformToUni(ignored -> jokeClient.getJoke())
                    .onItem().transformToUni(this::saveJokeToDb);
        }
        return jokeFetchingUni.onItem().transformToUni(ignored -> fetchAllSavedJokes());
    }

    private Uni<Void> saveJokeToDb(Joke joke) {
        System.out.println("Fetched Joke: " + joke);
        if (joke.getSetup() == null || joke.getPunchline() == null) {
            System.out.println("Skipping invalid joke: setup or punchline is null");
            return Uni.createFrom().voidItem();
        }
        String insertQuery = "INSERT INTO jokes (id, question, answer) VALUES (?, ?, ?)";
        return mysqlClient.preparedQuery(insertQuery)
                .execute(Tuple.of(joke.getId(), joke.getSetup(), joke.getPunchline()))
                .replaceWithVoid();
    }
    private Uni<List<Joke>> fetchAllSavedJokes() {
        String selectQuery = "SELECT id, question, answer FROM jokes";
        return mysqlClient.query(selectQuery).execute()
                .onItem().transformToMulti(set -> Multi.createFrom().iterable(set))
                .onItem().transform(this::mapRowToJoke)
                .collect().asList();
    }
    private Joke mapRowToJoke(Row row) {
        Joke joke = new Joke();
        joke.setId(row.getString("id"));
        joke.setSetup(row.getString("question"));
        joke.setPunchline(row.getString("answer"));
        return joke;
    }
}

package org.quarkus.jokes1.Controller;

import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;
import org.quarkus.jokes1.Entity.Joke;

@RegisterRestClient(baseUri = "https://official-joke-api.appspot.com/")
public interface JokeClient {
    @GET
    @Path("/random_joke")
    Uni<Joke> getJoke();


}
